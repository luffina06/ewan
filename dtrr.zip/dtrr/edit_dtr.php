<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

include ('conn.php');

if (isset($_POST['updatedata'])) {
    $dtrID = $_POST['updatedata'];
    $empID = $_POST['selectedName_ID'];
    $AMin = $_POST['AMin'];
    $AMout = $_POST['AMout'];
    $PMin = $_POST['PMin'];
    $PMout = $_POST['PMout'];
    $editlunch = $_POST['lunch'];

    $am_clockin = new DateTime($AMin);
    $am_clockout = new DateTime($AMout);
    $pm_clockin = new DateTime($PMin);
    $pm_clockout = new DateTime($PMout);

    if($AMin != null && $AMout != null && $PMin != null && $PMout != null){
        $am_interval = $am_clockin->diff($am_clockout);
        $pm_interval = $pm_clockin->diff($pm_clockout);
        $lunch_interval = $am_clockout->diff($pm_clockin);

        $lunch_minutes = ($lunch_interval->h * 60) + $lunch_interval->i;
        $am_minutes = ($am_interval->h * 60) + $am_interval->i;
        $pm_minutes = ($pm_interval->h * 60) + $pm_interval->i;

        if($editlunch == 0){
            $lunch = 0;
        }else{
            if($lunch_minutes <= $editlunch){
                $lunch = $editlunch;
            }else{
                $lunch = $lunch_minutes;
            }
        }
        $total_minutes = $am_minutes + $pm_minutes - $lunch;
        $total_hours = ($total_minutes / 60);

        $updateDtrSql = "UPDATE tbl_initialdtr SET am_clockin = ?, am_clockout = ?, pm_clockin = ?, pm_clockout = ?, totalhours = ? WHERE employee_id = ? AND id = ?";
        $updateDtrStmt = $conn->prepare($updateDtrSql);
        $updateDtrStmt->bind_param('ssssdii', $AMin, $AMout, $PMin, $PMout, $total_hours, $empID, $dtrID);
        $updateDtrStmt->execute();
        $updateDtrStmt->close();

        $updateDtrSql = "UPDATE tbl_dtr SET am_clockin = ?, am_clockout = ?, pm_clockin = ?, pm_clockout = ?, totalhours = ? WHERE employee_id = ? AND id = ?";
        $updateDtrStmt = $conn->prepare($updateDtrSql);
        $updateDtrStmt->bind_param('ssssdii', $AMin, $AMout, $PMin, $PMout, $total_hours, $empID, $dtrID);
        $updateDtrStmt->execute();
        $updateDtrStmt->close();
    }else if($AMin != null && $AMout == null && $PMin == null && $PMout != null){
        $time_interval = $am_clockin->diff($pm_clockout);
        $time_minutes = ($time_interval->h * 60) + $time_interval->i;
        if($editlunch == 0){
            $lunch = 0;
        }else{
            $lunch = $editlunch; 
        }
        
        $total_minutes = $time_minutes - $lunch;
        $total_hours = ($total_minutes / 60);

        $updateDtrSql = "UPDATE tbl_initialdtr SET am_clockin = ?, am_clockout = ?, pm_clockin = ?, pm_clockout = ?, totalhours = ? WHERE employee_id = ? AND id = ?";
        $updateDtrStmt = $conn->prepare($updateDtrSql);
        $updateDtrStmt->bind_param('ssssdii', $AMin, $AMout, $PMin, $PMout, $total_hours, $empID, $dtrID);
        $updateDtrStmt->execute();
        $updateDtrStmt->close();

        $updateDtrSql = "UPDATE tbl_dtr SET am_clockin = ?, am_clockout = ?, pm_clockin = ?, pm_clockout = ?, totalhours = ? WHERE employee_id = ? AND id = ?";
        $updateDtrStmt = $conn->prepare($updateDtrSql);
        $updateDtrStmt->bind_param('ssssdii', $AMin, $AMout, $PMin, $PMout, $total_hours, $empID, $dtrID);
        $updateDtrStmt->execute();
        $updateDtrStmt->close();
    }else if($AMin != null && $AMout != null && $PMin == null && $PMout == null){
        $am_interval = $am_clockin->diff($am_clockout);
        $am_minutes = ($am_interval->h * 60) + $am_interval->i;

        if($editlunch == 0){
            $lunch = 0;
        }else{
            $lunch = $editlunch; 
        }
        $total_minutes = $am_minutes - $lunch;
        $total_hours = ($total_minutes / 60);

        $updateDtrSql = "UPDATE tbl_initialdtr SET am_clockin = ?, am_clockout = ?, pm_clockin = ?, pm_clockout = ?, totalhours = ? WHERE employee_id = ? AND id = ?";
        $updateDtrStmt = $conn->prepare($updateDtrSql);
        $updateDtrStmt->bind_param('ssssdii', $AMin, $AMout, $PMin, $PMout, $total_hours, $empID, $dtrID);
        $updateDtrStmt->execute();
        $updateDtrStmt->close();

        $updateDtrSql = "UPDATE tbl_dtr SET am_clockin = ?, am_clockout = ?, pm_clockin = ?, pm_clockout = ?, totalhours = ? WHERE employee_id = ? AND id = ?";
        $updateDtrStmt = $conn->prepare($updateDtrSql);
        $updateDtrStmt->bind_param('ssssdii', $AMin, $AMout, $PMin, $PMout, $total_hours, $empID, $dtrID);
        $updateDtrStmt->execute();
        $updateDtrStmt->close();
    }else if($AMin == null && $AMout == null && $PMin != null && $PMout != null){
        $pm_interval = $pm_clockin->diff($pm_clockout);
        $pm_minutes = ($pm_interval->h * 60) + $pm_interval->i;
        if($editlunch == 0){
            $lunch = 0;
        }else{
            $lunch = $editlunch; 
        }
        $total_minutes = $pm_minutes-$lunch;
        $total_hours = ($total_minutes / 60);

        $updateDtrSql = "UPDATE tbl_initialdtr SET am_clockin = ?, am_clockout = ?, pm_clockin = ?, pm_clockout = ?, totalhours = ? WHERE employee_id = ? AND id = ?";
        $updateDtrStmt = $conn->prepare($updateDtrSql);
        $updateDtrStmt->bind_param('ssssdii', $AMin, $AMout, $PMin, $PMout, $total_hours, $empID, $dtrID);
        $updateDtrStmt->execute();
        $updateDtrStmt->close();

        $updateDtrSql = "UPDATE tbl_dtr SET am_clockin = ?, am_clockout = ?, pm_clockin = ?, pm_clockout = ?, totalhours = ? WHERE employee_id = ? AND id = ?";
        $updateDtrStmt = $conn->prepare($updateDtrSql);
        $updateDtrStmt->bind_param('ssssdii', $AMin, $AMout, $PMin, $PMout, $total_hours, $empID, $dtrID);
        $updateDtrStmt->execute();
        $updateDtrStmt->close();
    }



















}
echo "<script>window.alert('dtr edited successfully');
window.location.href='dtr.php';</script>";
?>